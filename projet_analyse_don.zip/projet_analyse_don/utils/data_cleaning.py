import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from textblob import TextBlob
from spellchecker import SpellChecker
import re
from unidecode import unidecode
import unicodedata



def afficher_valeurs_manquantes(df):
    """
    Affiche un tableau avec les colonnes et leur pourcentage de valeurs manquantes.

    Paramètre:
    -----------
    - df : DataFrame (Dataset à analyser)

    Retour:
    --------
    - DataFrame affichant les colonnes et leur pourcentage de valeurs manquantes
    """
    # Calcul des valeurs manquantes en pourcentage
    missing_data = df.isnull().sum() / len(df) * 100

    # Filtrer les colonnes ayant des valeurs manquantes uniquement
    missing_data = missing_data[missing_data > 0].sort_values(ascending=False)

    # Créer un DataFrame formaté
    missing_df = pd.DataFrame({
        'Colonne': missing_data.index,
        'Pourcentage_manquant (%)': missing_data.values
    })

    # Afficher les résultats
    return missing_df.reset_index(drop=True)

# Dictionnaire des colonnes
COLUMNS = {
    "DATE_DE_REMPLISSAGE" : 'date_de_remplissage',
    "DATE_DE_NAISSANCE": 'date_de_naissance',
    "AGE": 'age',
    "NIVEAU_ETUDE": 'niveau_d_etude',
    "GENRE": 'genre',
    "TAILLE": 'taille',
    "POIDS": 'poids',
    "VILLE": 'ville',
    "SITUATION_MATRIMONIALE": 'situation_matrimoniale_(sm)',
    "PROFESSION": 'profession',
    "ARRONDISSEMENT_DE_RESIDENCE": 'arrondissement_de_residence',
    "QUARTIER_DE_RESIDENCE": 'quartier_de_residence',
    "NATIONALITE": 'nationalite',
    "RELIGION": 'religion',
    "A_TIL_ELLE_DEJA_DONNE_LE_SANG": 'a_t_il_elle_deja_donne_le_sang',
    "SI_OUI_PRECISER_LA_DATE_DU_DERNIER_DON": 'si_oui_preciser_la_date_du_dernier_don',
    "TAUX_HEMOGLOBINE": 'taux_d_hemoglobine',
    "ELIGIBILITE_AU_DON": 'eligibilite_au_don',
    "DATE_DE_DERNIERES_REGLES": 'date_de_dernieres_regles_(ddr)',
    "AUTRE_RAISON": 'autre_raisons,__preciser',
    "SELECTIONNER_OK_POUR_ENVOYER": 'selectionner_"ok"_pour_envoyer',
    "SI_AUTRES_RAISON_PRECISER": 'si_autres_raison_preciser',
    "RAISON_INDISPONIBILITE" : [
        'raison_indisponibilité__[est_sous_anti-biothérapie__]',
        'raison_indisponibilité__[taux_d’hémoglobine_bas_]',
        'raison_indisponibilité__[date_de_dernier_don_<_3_mois_]',
        'raison_indisponibilité__[ist_récente_(exclu_vih,_hbs,_hcv)]'
    ],
    "RAISON_INDISPONIBILITE_FEMME" : [
        'raison_de_l’indisponibilité_de_la_femme_[la_ddr_est_mauvais_si_<14_jour_avant_le_don]',
        'raison_de_l’indisponibilité_de_la_femme_[allaitement_]',
        'raison_de_l’indisponibilité_de_la_femme_[a_accoucher_ces_6_derniers_mois__]',
        'raison_de_l’indisponibilité_de_la_femme_[interruption_de_grossesse__ces_06_derniers_mois]',
        'raison_de_l’indisponibilité_de_la_femme_[est_enceinte_]'
    ],
    "RAISON_NON_ELIGIBLE" : [
        'raison_de_non-eligibilité_totale__[antécédent_de_transfusion]',
        'raison_de_non-eligibilité_totale__[porteur(hiv,hbs,hcv)]',
        'raison_de_non-eligibilité_totale__[opéré]',
        'raison_de_non-eligibilité_totale__[drepanocytaire]',
        'raison_de_non-eligibilité_totale__[diabétique]',
        'raison_de_non-eligibilité_totale__[hypertendus]',
        'raison_de_non-eligibilité_totale__[asthmatiques]',
        'raison_de_non-eligibilité_totale__[cardiaque]',
        'raison_de_non-eligibilité_totale__[tatoué]',
        'raison_de_non-eligibilité_totale__[scarifié]'
    ]
}

TYPE_ELIGIBILITE = {
    'ELIGIBLE': 'eligible',
    'TEMPORAIREMENT_NON_ELIGIBLE': 'temporairement non-eligible',
    'DEFINITIVEMENT_NON_ELIGIBLE': 'définitivement non-eligible'
}

# Dictionnaire de correspondance des colonnes (mapping)
COLUMNS_FORMATED = {
    'horodateur': COLUMNS['DATE_DE_REMPLISSAGE'],
    'date_de_remplissage_de_la_fiche': COLUMNS['DATE_DE_REMPLISSAGE'],
    'âge': COLUMNS['AGE'],
    'niveau_d\'etude': COLUMNS['NIVEAU_ETUDE'],
    'genre_': COLUMNS['GENRE'],
    'taille_': COLUMNS['TAILLE'],
    'profession_': COLUMNS['PROFESSION'],
    'arrondissement_de_résidence_': COLUMNS['ARRONDISSEMENT_DE_RESIDENCE'],
    'arrondissement_de_résidence': COLUMNS['ARRONDISSEMENT_DE_RESIDENCE'],
    'quartier_de_résidence_': COLUMNS['QUARTIER_DE_RESIDENCE'],
    'quartier_de_résidence': COLUMNS['QUARTIER_DE_RESIDENCE'],
    'nationalité_': COLUMNS['NATIONALITE'],
    'nationalité': COLUMNS['NATIONALITE'],
    'a-t-il_(elle)_déjà_donné_le_sang': COLUMNS['A_TIL_ELLE_DEJA_DONNE_LE_SANG'],
    'si_oui_preciser_la_date_du_dernier_don.': COLUMNS['SI_OUI_PRECISER_LA_DATE_DU_DERNIER_DON'],
    'religion_': COLUMNS['RELIGION'],
    'a-t-il_(elle)_déjà_donné_le_sang_': COLUMNS['A_TIL_ELLE_DEJA_DONNE_LE_SANG'],
    'si_oui_preciser_la_date_du_dernier_don._': COLUMNS['SI_OUI_PRECISER_LA_DATE_DU_DERNIER_DON'],
    'taux_d’hémoglobine_': COLUMNS['TAUX_HEMOGLOBINE'],
    'taux_d’hémoglobine': COLUMNS['TAUX_HEMOGLOBINE'],
    'éligibilité_au_don.': COLUMNS['ELIGIBILITE_AU_DON'],
    'date_de_dernières_règles_(ddr)__': COLUMNS['DATE_DE_DERNIERES_REGLES'],
    'date_de_dernières_règles_(ddr)': COLUMNS['DATE_DE_DERNIERES_REGLES'],
    'autre_raisons,__preciser_': COLUMNS['AUTRE_RAISON'],
    'sélectionner_"ok"_pour_envoyer_': COLUMNS['SELECTIONNER_OK_POUR_ENVOYER'],
    'sélectionner_"ok"_pour_envoyer': COLUMNS['SELECTIONNER_OK_POUR_ENVOYER'],
    'si_autres_raison_préciser_' : COLUMNS['SI_AUTRES_RAISON_PRECISER'],
    'si_autres_raison_préciser' : COLUMNS['SI_AUTRES_RAISON_PRECISER']
}

# Re-création de la fonction après la réinitialisation
def examiner_colonne(df, colonne):
    """
    Examine en profondeur une colonne spécifique d'un DataFrame et affiche les résultats,
    en distinguant les colonnes qualitatives et quantitatives.

    Paramètres :
    - df (pd.DataFrame) : Le DataFrame contenant les données.
    - colonne (str) : Le nom de la colonne à examiner.

    Retourne :
    - Un résumé complet des caractéristiques de la colonne.
    """

    print(f"🔎 **Examen de la colonne : `{colonne}`**\n")

    # Identification du type de colonne (qualitative vs quantitative)
    if pd.api.types.is_numeric_dtype(df[colonne]):
        col_type = 'Quantitative'
    elif pd.api.types.is_object_dtype(df[colonne]):
        col_type = 'Qualitative'
    elif pd.api.types.is_datetime64_any_dtype(df[colonne]) or 'date' in colonne.lower():
        col_type = 'Date'
        # Conversion en format date si ce n'est pas déjà fait
        df[colonne] = pd.to_datetime(df[colonne], errors='coerce')

    print(f"📋 Type de colonne détecté : **{col_type}**\n")

    # 1. Informations générales
    print("📋 Informations générales :")
    print(f"- Type de données : {df[colonne].dtype}")
    print(f"- Nombre total de valeurs non-nulles : {df[colonne].notnull().sum()} / {len(df)}")
    print(f"- Proportion de valeurs manquantes : {df[colonne].isnull().mean() * 100:.2f}%\n")

    # 2. Valeurs uniques
    print("🔹 Valeurs uniques :")
    print(f"- Nombre de valeurs uniques : {df[colonne].nunique()}")
    print(df[colonne].value_counts().head(10))  # Affiche les 10 premières valeurs les plus fréquentes
    print()

    # 3. Détection des incohérences (uniquement pour les colonnes qualitatives)
    if col_type == 'Qualitative':
        print("🟠 Vérification des incohérences :")
        print("- Présence d'espaces inutiles :", (df[colonne].str.strip() != df[colonne]).sum())
        print("- Présence de caractères spéciaux :", df[colonne].str.contains('[^a-zA-Z0-9 ]', na=False).sum())
        print()

        # Graphique de distribution pour les colonnes qualitatives
        plt.figure(figsize=(10, 6))
        sns.countplot(data=df, y=colonne, order=df[colonne].value_counts().index, palette='Blues_r')
        plt.title(f"Distribution des valeurs dans la colonne : {colonne}")
        plt.xlabel("Nombre d'occurrences")
        plt.ylabel("Catégories")
        plt.show()
        print()

        # Identification du mode (valeur la plus fréquente)
        mode_val = df[colonne].mode()[0]
        print(f"🏆 **Mode (valeur la plus fréquente) :** `{mode_val}`")

    # 4. Doublons
    # print("🟡 Vérification des doublons :")
    # print(f"- Nombre de doublons : {df[colonne].duplicated().sum()}")
    # print()

    # 5. Statistiques descriptives pour les colonnes quantitatives
    if col_type == 'Quantitative':
        print("📊 Statistiques descriptives :")
        print(df[colonne].describe())

        # Histogramme
        plt.figure(figsize=(8, 5))
        sns.histplot(df[colonne], bins=20, kde=True)
        plt.title(f"Distribution de la colonne : {colonne}")
        plt.show()

        # Boxplot
        plt.figure(figsize=(6, 4))
        sns.boxplot(x=df[colonne])
        plt.title(f"Boxplot de la colonne : {colonne}")
        plt.show()

    # 6. Valeurs inhabituelles et manquantes
    print("🔵 Analyse des valeurs inhabituelles :")
    print(df[colonne].value_counts(dropna=False).head(10))
    print()

    # 7. Analyse spécifique pour les colonnes de type Date
    if col_type == 'Date':
        print("🗓️ Analyse temporelle de la colonne date :")
        
        # Affichage de la plage de dates
        print(f"- Date la plus ancienne : {df[colonne].min()}")
        print(f"- Date la plus récente : {df[colonne].max()}")
        
        # Histogramme des dates
        plt.figure(figsize=(10, 6))
        sns.histplot(df[colonne].dropna(), kde=True, bins=20, color='teal')
        plt.title(f"Distribution temporelle de la colonne : {colonne}")
        plt.xlabel("Date")
        plt.show()

        # Détail par année/mois
        print("🔎 Répartition par année :")
        print(df[colonne].dt.year.value_counts().sort_index())
        
        print("\n🔎 Répartition par mois (tous les mois confondus) :")
        print(df[colonne].dt.month.value_counts().sort_index())


    # # 7. Vérification du format des dates
    # if 'date' in colonne.lower() or pd.api.types.is_datetime64_any_dtype(df[colonne]):
    #     print("🗓️ Vérification des formats de date :")
    #     try:
    #         df[colonne] = pd.to_datetime(df[colonne], errors='coerce')
    #         print("- Conversion réussie en format date.")
    #     except Exception as e:
    #         print(f"- Erreur lors de la conversion en date : {e}")

    # 8. Outliers (uniquement pour les colonnes quantitatives)
    if col_type == 'Quantitative':
        print("🚨 Outliers détectés :")
        Q1 = df[colonne].quantile(0.25)
        Q3 = df[colonne].quantile(0.75)
        IQR = Q3 - Q1
        outliers = df[(df[colonne] < (Q1 - 1.5 * IQR)) | (df[colonne] > (Q3 + 1.5 * IQR))]
        print(f"- Nombre d'outliers détectés : {len(outliers)}\n")

    print("✅ **Examen terminé**\n")


def standardiser_colonne(df, colonne, correction_mapping={}):
    """
    Standardise les valeurs d'une colonne qualitative en :
    - Supprimant les espaces inutiles
    - Corrigeant les éventuels caractères spéciaux
    - Uniformisant la casse (majuscule/minuscule)
    - Remplaçant les valeurs similaires ou incohérentes par des libellés standards

    Paramètres :
    - df (pd.DataFrame) : DataFrame contenant les données
    - colonne (str) : Nom de la colonne à standardiser

    Retourne :
    - DataFrame avec la colonne standardisée
    """
    # Supprimer les espaces inutiles au début et à la fin
    df[colonne] = df[colonne].str.strip()

    # Suppression des caractères spéciaux inattendus
    # df[colonne] = df[colonne].str.replace(r'[^a-zA-Z0-9À-ÖØ-öø-ÿ\s-]', '', regex=True)

    # Remplacer plusieurs espaces consécutifs par un seul espace
    df[colonne] = df[colonne].str.replace(r'\s+', ' ', regex=True)

    # Uniformisation de la casse (tout en minuscule)
    df[colonne] = df[colonne].str.lower()

    df[colonne] = df[colonne].replace(correction_mapping)

    print(f"✅ Colonne `{colonne}` standardisée avec succès !")

    return df


def standardiser_group_colonnes(df, colonnes):
    """
    Standardise les valeurs de plusieurs colonnes qualitatives en :
    - Supprimant les espaces inutiles
    - Corrigeant les éventuels caractères spéciaux
    - Uniformisant la casse (majuscule/minuscule)
    - Remplaçant les valeurs similaires ou incohérentes par des libellés standards

    Paramètres :
    - df (pd.DataFrame) : DataFrame contenant les données
    - colonnes (list) : Liste des colonnes à standardiser

    Retourne :
    - DataFrame avec les colonnes standardisées
    """
    correction_mapping = {
        'eligible': 'Eligible',
        'temporairement non-eligible': 'Temporairement Non-eligible',
        'définitivement non-eligible': 'Définitivement Non-eligible',
        'consommation de drogue': 'consommation de drogues',
        'cocaïne': 'consommation de drogues',
        'eu à consommer de la cocaïne et d autre drogues': 'consommation de drogues',
        'rapport non proteger': 'rapport non protégé',
        'rapports non proteges': 'rapport non protégé',
        'rapport non protege': 'rapport non protégé',
        'ras': 'non',
        'pas de raison specifiques': 'non',
        'raison non precisee': 'non',
        'aucune': 'non',
        'changé de partenaire et eu des rapports non protégé': 'rapport non protégé et changement de partenaire',
        'prise dun médicament diclojenac': 'prise de médicament diclojenac',
        'pris de médicaments diclojenal': 'prise de médicament diclojenac',
        'drogues': 'consommation de drogues',
        'aucune information': 'aucune',
        'pas d information sur son dossier': 'aucune',
        'ete traite par acupuncture': 'aucune',
    }

    # Boucle sur chaque colonne spécifiée
    for colonne in colonnes:
        # Supprimer les espaces inutiles au début et à la fin
        df[colonne] = df[colonne].str.strip()

        # Suppression des caractères spéciaux inattendus (en gardant les espaces entre les mots)
        df[colonne] = df[colonne].str.replace(r'[^a-zA-Z0-9À-ÖØ-öø-ÿ\s]', '', regex=True)

        # Remplacer plusieurs espaces consécutifs par un seul espace
        df[colonne] = df[colonne].str.replace(r'\s+', ' ', regex=True)

        # Uniformisation de la casse (tout en minuscule)
        df[colonne] = df[colonne].str.lower()

        # Correction et remplacement des libellés incohérents
        df[colonne] = df[colonne].replace(correction_mapping)

        print(f"✅ Colonne `{colonne}` standardisée avec succès !")

    return df

def modifier_valeurs(df, condition, colonne_cible, nouvelle_valeur):
    """
    Modifie les valeurs d'une colonne spécifique dans les lignes qui respectent une condition donnée.

    Paramètres :
    - df (pd.DataFrame) : Le DataFrame contenant les données.
    - condition (pd.Series) : La condition pour filtrer les lignes à modifier.
    - colonne_cible (str) : Le nom de la colonne dont les valeurs doivent être modifiées.
    - nouvelle_valeur (str) : La valeur qui remplacera les anciennes.

    Retourne :
    - Le DataFrame avec les modifications apportées.
    """
    # Vérification que la colonne existe
    if colonne_cible in df.columns:
        df.loc[condition, colonne_cible] = nouvelle_valeur
        print(f"✅ La colonne `{colonne_cible}` a été mise à jour avec la valeur `{nouvelle_valeur}` pour les lignes respectant la condition.")
    else:
        print(f"❌ La colonne `{colonne_cible}` n'existe pas dans le DataFrame.")
    
    return df

# Fonction pour détecter et remplacer uniquement les dates avec le séparateur '/'
def remplacer_separateur(date_str):
    """
    Remplace les séparateurs '/' par '-' dans une chaîne de date,
    en ignorant les valeurs manquantes ou non valides.

    Paramètres :
    - date_str (str) : Chaîne de caractères représentant une date.

    Retourne :
    - La date avec les séparateurs corrigés ou la valeur d'origine si elle est manquante/incorrecte.
    """
    try:
        # Ignorer les valeurs manquantes
        if pd.isnull(date_str) or date_str == '':
            return date_str
        
        # Convertir en chaîne de caractères si ce n'est pas déjà le cas
        date_str = str(date_str)
        
        # Vérifier si le séparateur est '/' et remplacer par '-'
        if '/' in date_str:
            return date_str.replace('/', '-')
        return date_str  # Retourner inchangé si le séparateur n'est pas '/'
    except Exception as e:
        # Gérer les cas imprévus
        print(f"Erreur : {e}")
        return date_str

def corriger_valeurs(dataframe, colonne, motif, remplacement):
    """
    Corrige les valeurs dans une colonne spécifique d'un DataFrame en remplaçant un motif par une nouvelle valeur.
    :param dataframe: Le DataFrame contenant les données
    :param colonne: Le nom de la colonne à analyser
    :param motif: Le motif à rechercher dans les valeurs
    :param remplacement: La valeur par laquelle remplacer le motif
    :return: Le DataFrame mis à jour
    """
    def corriger_element(element):
        try:
            # Remplacer le motif par la nouvelle valeur
            if isinstance(element, str) and motif in element:
                return element.replace(motif, remplacement)
            return element
        except AttributeError:
            # Gérer les cas où la valeur n'est pas une chaîne
            return element

    dataframe[colonne] = dataframe[colonne].apply(corriger_element)
    return dataframe

def extraire_voisins_avant_valeurs_manquantes(dataframe, colonne, marge=2):
    """
    Filtre les lignes contenant des valeurs manquantes et inclut les n lignes précédentes.
    :param dataframe: Le DataFrame contenant les données
    :param colonne: Le nom de la colonne à analyser
    :param marge: Le nombre de lignes précédentes à inclure
    :return: Un DataFrame contenant les lignes filtrées
    """
    # Indices des valeurs manquantes
    indices_manquants = dataframe[dataframe[colonne].isna()].index

    # Indices à inclure (manquants + précédents)
    indices_voisins = set()
    for idx in indices_manquants:
        indices_voisins.update(range(max(0, idx - marge), idx + 1))  # +1 pour inclure la ligne manquante elle-même

    # Filtrage des lignes
    return dataframe.loc[sorted(indices_voisins)]

def remplacer_dates_manquantes(dataframe, colonne):
    """
    Remplace les valeurs manquantes dans une colonne de dates par des dates croissantes,
    en utilisant la dernière date valide précédant la valeur manquante.
    :param dataframe: Le DataFrame contenant les données
    :param colonne: Le nom de la colonne contenant les dates
    :return: Le DataFrame mis à jour
    """
    # Assurez-vous que la colonne est bien au format datetime
    dataframe[colonne] = pd.to_datetime(dataframe[colonne], errors='coerce')
    
    # Parcours des lignes pour remplacer les valeurs manquantes
    for i in range(len(dataframe)):
        if pd.isna(dataframe.loc[i, colonne]):  # Si la valeur est manquante
            # Prendre la dernière date valide
            date_precedente = dataframe.loc[i - 1, colonne] if i > 0 else None
            if date_precedente is not None:  # Si une date précédente existe
                # Ajouter un jour à cette date
                dataframe.loc[i, colonne] = date_precedente + pd.Timedelta(days=1)

    return dataframe


# formatage des date tu type MM/DD/YYYY en "YYYY-MM-DD"
def format_date(column):
    """
    Formate une colonne de dates en ignorant les valeurs déjà bien formatées et les valeurs manquantes.
    """
    def process_date(value):
        # Ignorer les valeurs manquantes
        if pd.isna(value):
            return value
        
        # Vérifier si la valeur est déjà bien formatée
        try:
            # Tenter de convertir la valeur en datetime avec le format cible
            pd.to_datetime(value, format="%Y-%m-%d %H:%M:%S")
            return value  # Si cela fonctionne, retourner la valeur telle quelle
        except ValueError:
            pass  # Si une erreur survient, continuer pour reformater
        
        # Si la valeur n'est pas bien formatée, tenter de la reformater
        try:
            return pd.to_datetime(value, format="%m/%d/%Y").strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            # Si la valeur ne correspond à aucun format attendu, retourner NaT
            return pd.NaT

    # Appliquer la fonction à chaque valeur de la colonne
    return column.apply(process_date)

# def corriger_annees_incorrectes(df, colonne):
#     """
#     Corrige automatiquement les années incorrectes dans une colonne de dates.

#     Paramètres :
#     - df (pd.DataFrame) : DataFrame contenant les données.
#     - colonne (str) : Nom de la colonne contenant les dates.

#     Retourne :
#     - DataFrame corrigé avec les années remises en format correct.
#     """
#     # Extraction et correction des années commençant par "00xx"
#     for annee in df[colonne].dropna().unique():
#         # Années sous la forme "00xx" ➔ Remplacement par "19xx"
#         if re.match(r'^00\d{2}$', str(annee)):
#             annee_corrigee = "19" + str(annee)[2:]
#             df = corriger_valeurs(df, colonne, motif=str(annee), remplacement=annee_corrigee)
        
#         # Années sous la forme "000x" ➔ Remplacement par "200x"
#         elif re.match(r'^000\d$', str(annee)):
#             annee_corrigee = "200" + str(annee)[3:]
#             df = corriger_valeurs(df, colonne, motif=str(annee), remplacement=annee_corrigee)

#     print(f"✅ Les années incorrectes ont été corrigées dans la colonne `{colonne}`.")
#     return df

def corriger_arrondissement(df, colonne_arrondissement, colonne_quartier, villes):
    """
    Corrige les valeurs 'pas précisé' dans la colonne des arrondissements en recherchant
    l'arrondissement correspondant au quartier mentionné dans le dictionnaire des villes.

    Paramètres :
    - df (pd.DataFrame) : DataFrame contenant les données
    - colonne_arrondissement (str) : Nom de la colonne des arrondissements
    - colonne_quartier (str) : Nom de la colonne des quartiers
    - villes (dict) : Dictionnaire contenant les villes, arrondissements et quartiers

    Retourne :
    - DataFrame corrigé avec les arrondissements mis à jour lorsque possible
    """
    for index, row in df.iterrows():
        arrondissement = unidecode(str(row[colonne_arrondissement]).strip().lower())
        quartier = unidecode(str(row[colonne_quartier]).strip().lower()) if pd.notna(row[colonne_quartier]) else ''

        # Vérification des conditions : arrondissement "pas précisé" et quartier valide
        if arrondissement in ['pas precise', 'douala(pas precise)', 'yaounde(pas precise)'] and quartier and quartier != 'pas precise':
            # Recherche de l'arrondissement correspondant au quartier dans le dictionnaire des villes
            arrondissement_trouve = None
            for ville, arrondissements in villes.items():
                for arr, quartiers in arrondissements.items():
                    if quartier in [unidecode(q).lower() for q in quartiers]:
                        arrondissement_trouve = unidecode(arr).lower()
                        break
                if arrondissement_trouve:
                    break
            
            # Mise à jour du DataFrame si l'arrondissement est trouvé
            if arrondissement_trouve:
                df.at[index, colonne_arrondissement] = arrondissement_trouve

    print("✅ Correction des arrondissements terminée avec succès (en minuscule et sans accents).")
    return df

# Re-création du script sans utiliser 'unidecode' (en remplaçant par une solution interne sans module externe)
def enlever_accents(texte):
    """Supprime les accents d'un texte pour améliorer les correspondances."""
    return ''.join(c for c in unicodedata.normalize('NFD', texte) if unicodedata.category(c) != 'Mn')

def ajouter_colonne_ville(df, colonne_arrondissement, colonne_quartier, villes):
    """
    Crée une colonne 'Ville' en déterminant la ville correspondant à l'arrondissement ou au quartier.

    Paramètres :
    - df (pd.DataFrame) : DataFrame contenant les données
    - colonne_arrondissement (str) : Nom de la colonne des arrondissements
    - colonne_quartier (str) : Nom de la colonne des quartiers
    - villes (dict) : Dictionnaire contenant les villes, arrondissements et quartiers

    Retourne :
    - DataFrame avec la colonne 'Ville' ajoutée
    """
    # Initialiser la colonne 'Ville' avec la valeur par défaut "inconnu"
    df[COLUMNS['VILLE']] = 'inconnu'

    # Parcourir chaque ligne du DataFrame
    for index, row in df.iterrows():
        arrondissement = enlever_accents(str(row[colonne_arrondissement]).strip().lower())
        quartier = enlever_accents(str(row[colonne_quartier]).strip().lower()) if pd.notna(row[colonne_quartier]) else ''

        # Vérifier si l'arrondissement ou le quartier mentionne une ville (ex: "douala", "yaoundé")
        for ville in villes.keys():
            if ville.lower() in arrondissement or ville.lower() in quartier:
                df.at[index, COLUMNS['VILLE']] = ville.lower()
                break

        # Si aucune ville n'a été trouvée, vérifier dans le dictionnaire
        if df.at[index, COLUMNS['VILLE']] == 'inconnu':
            for ville, arrondissements in villes.items():
                for arr, quartiers in arrondissements.items():
                    if arrondissement in enlever_accents(arr).lower() or quartier in [enlever_accents(q).lower() for q in quartiers]:
                        df.at[index, COLUMNS['VILLE']] = ville.lower()
                        break
                if df.at[index, COLUMNS['VILLE']] != 'inconnu':
                    break

    print(f"✅ Colonne {COLUMNS['VILLE']} ajoutée avec succès.")
    return df

# Fonction d'analyse de sentiment
def analyser_sentiment(texte):
    analyse = TextBlob(texte)
    if analyse.sentiment.polarity > 0:
        return 'Positif'
    elif analyse.sentiment.polarity < 0:
        return 'Négatif'
    else:
        return 'Neutre'
    