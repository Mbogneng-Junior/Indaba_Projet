# Dictionnaire de ville, arrondissement et quartier 
VILLES = {
    "DOUALA" : {
        "Douala 1": [
            "Akwa", "Bali", "Bonanjo", "Bonapriso", "Deïdo",
            "Bonamikengue", "Bessengue", "Bonamoudourou", "Bona Bekombo",
            "Bonamouti Akwa 2", "Bonadibong", "Bonamouti", "Bonadouma",
            "Bonadoumbé", "Bonajinje", "Bonateki", "Bonakouamouang",
            "Bonatene", "Bonalembe", "Bonantone", "Bonajang",
            "Hydrocarbures", "Bonelang", "Plateau Joss", "Bonoleke",
            "Koumassi", "Bonakeke Akwa", "Ngodi", "Grand Moulin",
            "Nkongmondo", "Nouvelle zone d'Akwa Nord", "Nouvelle zone de New-Deido"
        ],
        "Douala 2": [
            "New Bell", "Bépanda", "Village", "Cité des Palmiers",
            "Aéroport", "Babylone I", "Babylone II", "Bonadouma",
            "Congo", "Kassalafam", "Lagos Market", "Lycée de New Bell",
            "Mbam Ewondo", "Ndjong-Mebi", "Nkololoum", "Ngangue",
            "Prison centrale de New Bell", "Sabenjongo", "Source",
            "T.S.F", "Youpwé"
        ],
        "Douala 3": [
            "Bonanloka", "Bilongue", "Bobongo", "Boko", "Bonadiwoto",
            "Brazzaville", "C.C.C.", "Cité Berge", "Cité de la Paix",
            "Dibom", "Japoma", "Logbaba", "Brazzaville", "Madiba", 
            "Ndogbatti", "Ndoghem II", "Ndogpassi", "Ndogsimbi", 
            "Ndokoti", "Nkongui", "Nyalla", "Nylon", "Oyack", "Pk 10",
            "Pk 9", "Pk 11", "Bonamoutongo", "Pk 7", "Kondi",
            "Pom Lien", "Sincatex", "So-Boum", "Song-Mahop",
            "Song-Ngongang", "Sopom", "Tergal", "Mbanga Bakoko",
            "Pk 17", "Pk 21"
        ],
        "Douala 4": [
            "Bonandale", "Besseke", "Bilingue", "Bonamatoumbe",
            "Bonambappe", "Bonamikano", "Bonassama", "Djébalé",
            "Mambanda", "Ndobo", "Ngwele", "Nkomba", "Sodiko", "Bwapé"
        ],
        "Douala 5": [
            "Bangue", "Beedi", "Bépanda", "Bonabeyike", "Bonamoussadi (Douala)",
            "Bonangang", "Bonangang", "Cacao-Barry", "Cité des Palmiers",
            "Cité Sic", "Dikahé", "Emene City", "Gentil", "Jourdain",
            "Kotto", "Lendi", "Logbessou", "Logpom", "Makepe", "Malanque",
            "Manike", "Mbengue City", "Ndogbati", "Ndogbong", "Ndoghem",
            "Ndogmbe", "Ngoma", "Ngurecek", "Bomkul", "NKondi",
            "Nguibassal", "Sobikago", "Sodikombo", "Ndogsimbi"
        ],
        "Douala 6": [
            "Manoka", "Dahomey", "Number One Creek", "Nyangadou",
            "Mbénandikoumé", "Epaka I", "Epaka II", "BuBessoukoudo",
            "Moukala Tanda", "Kombo", "Bouma", "Moungangué", "Kombo Moukoko",
            "Poka I", "Akra Kombo", "Cap Cameroun", "Petit Toubé",
            "Bikoro", "Koo", "Missipi", "Matanda Massadi"
        ]
    },

    "YAOUNDE": {
        "Yaoundé 1": [
            "Centre commercial", "Elig-Essono", "Etoa-Meki 1 (Onambélé Nku)", 
            "Nlongkak", "Elig-Edzoa", "Bastos", "Manguier", "Tongolo", "Mballa 1", 
            "Mballa 2", "Nkolondom", "Etoudi", "Messassi", "Okolo", "Olembe", "Nyom", 
            "Etoa-Meki 2", "Mballa 3", "Emana", "Nkoleton"
        ],
        "Yaoundé 2": [
            "Cité Verte", "Madagascar", "Mokolo", "Grand Messa", 
            "Ekoudou", "Tsinga", "Nkom-Kana", "Oliga", 
            "Messa Carrière", "École de Police", "Fébé", "Ntoungou"
        ],
        "Yaoundé 3": [
            "Obili", "Ngoa-Ekélé", "Nlong Mvolyé", 
            "Ahala 1", "Efoulan", "Obobogo", "Nsam", 
            "Melen 2 - Centre Administratif", "Etoa", 
            "Nkolmesseng 1", "Afanoya 1", "Afanoya 2", 
            "Afanoya 3", "Afanoya 4", "Nkolfon", "Mekoumbou 2", 
            "Ntouessong", "Mekoumbou 1", "Ahala 2", "Nsimeyong 1", 
            "Nsimeyong 2", "Nsimeyong 3", "Olezoa", "Dakar",
        ],
        "Yaoundé 4": [
            "Mvan-Nord", "Ndamvout", "Messame-Ndongo", 
            "Odza", "Ekoumdoum", "Awae", "Nkomo", "Ekounou", 
            "Biteng", "Kondengui 1", "Mimboman 1", "Etam-Bafia", 
            "Mvog-Mbi", "Nkol-Ndongo 2", "Mebandan", "Mvan-Sud", 
            "Ekié", "Emombo", "Kondengui 2", "Kondengui 3", 
            "Nkol-Ndongo 1", "Mimboman 3", "Ntui-Essong", "Nkolo", 
            "Abom", "Ekounou"
        ],
        "Yaoundé 5": [
            "Mvog-Ada", "Essos", "Nkol-Messing", "Nkol-Ebogo", 
            "Quartier Fouda", "Ngousso 1", "Éleveur", 
            "Mfandena 1", "Mfandena 2", "Ngousso 2", 
            "Ngousso-Ntem", "Ngoulmekong"
        ],
        "Yaoundé 6": [
            "Melen 8B et C", 
            "Etoug-Ebé 2", "Mvog-Betsi", "Biyem-Assi", 
            "Mendong 2", "Melen 8", "Simbock", "Etoug-Ebé 1", 
            "Melen", "Elig-Effa", "Nkolbikok", "Simbock École de guerre"
        ],
        "Yaoundé 7": [
            "Etetak", "Oyom-Abang", "Nkolbisson", "Minkoameyos", "Nkolso"
        ]
    }
}    