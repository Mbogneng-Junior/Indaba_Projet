# Projet d'Analyse des Dons de Sang

## 📋 Présentation
Ce projet vise à analyser les données de donneurs afin d'identifier les tendances et les critères d'éligibilité.

## 🛠️ Exécution des scripts
- Exécutez `nettoyage_volontaire.py` et `nettoyage_2019.py` pour nettoyer les données.
- Lancez `fusion_donnees.py` pour fusionner les données nettoyées.
- Utilisez `visualisation.py` pour afficher les résultats.

## 📊 Résultats clés
- Distribution des âges
- Taux d’éligibilité
- Analyse des motifs de non-éligibilité

